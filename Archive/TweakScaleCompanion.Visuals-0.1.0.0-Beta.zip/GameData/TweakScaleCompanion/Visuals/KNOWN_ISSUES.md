# TweakScale Companion :: Visuals :: Known Issues

* Restarting to Launch will reset the Engine's plumes to the default size
	 Appears to be something on Waterfall's life cycle that I didn't understand yet.

