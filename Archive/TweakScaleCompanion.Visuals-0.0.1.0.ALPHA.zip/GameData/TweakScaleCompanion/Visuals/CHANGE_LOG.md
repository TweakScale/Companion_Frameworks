# TweakScale Companion :: Visuals :: Change Log

* 2021-0530: 0.0.1.0 **ALPHA** (LisiasT) for KSP >= 1.8
	+ Initial public release
	+ **ALPHA** release, not ready for "production"
		- Compiled in DEBUG mode
		- See [KNOWN ISSUES](./KNOWN_ISSUES.md). 
